lambda = 0.1;
[all_theta] = oneVsAll(set, y, 5, lambda);

